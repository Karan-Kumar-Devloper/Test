<?php

	require_once realpath(dirname(__FILE__)) . '/../lib/blockio.php';
	require_once realpath(dirname(__FILE__)) . '/../config.php';

	function get_address_balance($address, $coin) {
		$b = new BlockIo(APIKEYS[$coin], PIN, 2);
		return (float)$b->get_address_balance(array('addresses' => $address))->data->available_balance;
	}
	
	function get_balance($coin) {
		$b = new BlockIo(APIKEYS[$coin], PIN, 2);
		return (float)$b->get_balance()->data->available_balance;
	}