<?php
	session_start ();
    if (isset($_SESSION ['id'])) header("Location: ../");

    require_once realpath(dirname(__FILE__)) . '/../utils/db.php';

    if (isset($_POST ['login']) and isset($_POST ['password'])) {
        if ($_POST['login'] == ADMIN_USERNAME && md5($_POST['password']) == ADMIN_PASSWORD_MD5) {
			$_SESSION["authorized"] = true;
			header("Location: index.php");
		}
        echo "Invalid login or password!";
    }
?>


<DOCTYPE html>
<html>
    <head>
<meta http-equiv="content-type" content="text/html; charset=utf8">
<title>ADMIN PANEL</title>
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
      
<style type="text/css">
BODY {background-image: url(https://img2.goodfon.ru/original/1512x945/9/e0/minimalizm-tekstura-geometriya.jpg);
background-attachment: fixed;
background-size: cover;
background-repeat: no-repeat;
}
*{
font-size: 14px;
}
.modal-dialog{
color: #000;
}
table.paytable{
font-size: 10px;
}
table.paytable tr{
padding: 5px;
}
table.paytable tr td{
padding: 5px;
}
.card-img-top {
    width: 100%;
    border-top-left-radius:0;
    border-top-right-radius:0;
}
.form form {
  width: 300px;
  margin: 0 auto;
  /*padding-top: 20px;*/
}
</style>
</head>
<body>
        <div style="padding-top: 5%;padding-bottom: 20%;">

<div class="container" style="margin-top: 10px;">
  
<div class="form">
<form class="form-horizontal" role="form" method="POST">
<div class="card">
  <div class="card-header">Login to your account</div>
  <div class="card-body">
<div align="center">

<img src="./img/logo.png" width="200" align="center"></div>
                <br><br>
    <div class="form-group">
    <label class="col-sm-12 control-label">Login</label>
    <div class="col-sm-12">
      <input type="text" class="form-control" placeholder="Login" name="login">
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-12 control-label">Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control" placeholder="password" name="password">
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-12">
      <button type="submit" name="submit" value="1" class="btn btn-success btn-sm">Auth</button>
    </div>
  </div>

  </div>
</div>

</form>
</div><!-- form  -->
        </div></div>
    </body>
</html>
