<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "toor");
	define("DB_NAME", "screensaver");
	
	define("ADMIN_USERNAME", "admin");
	define("ADMIN_PASSWORD_MD5", "21232f297a57a5a743894a0e4a801fc3"); // admin
	
	define("APIKEYS", array(
		"DOGE" => "",
		"LTC" => "",
		"BTC" => ""
	)); // Block.io api keys
	
	
	define("PIN", ""); // Block.io PIN
	
	define("PRICE", array(
		"DOGE" => 0.00289244,
		"BTC" => 6718.9,
		"LTC" => 82.98
	)); // medium price for cryptocurrencies in usd
	
	define("PAYMENT_SUM", array(
		"us" => array(
			"BTC" => 0.1,
			"LTC" => 0.05,
			"DOGE" => 10000
		),
		"" => array(
			"BTC" => 0.003,
			"LTC" => 0.05,
			"DOGE" => 5000
		) // all other countries
	));
?>