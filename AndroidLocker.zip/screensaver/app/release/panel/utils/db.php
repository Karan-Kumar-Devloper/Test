<?php

    require_once realpath(dirname(__FILE__)) . "/../config.php";

    function get_pdo () {
        return new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD);
    }

    function query ($query, $array) {
        $q = get_pdo()->prepare($query);
        if ($array != null) $q->execute($array);
        else $q->execute();

        return $q->fetchAll();
    }
	
	function add_client($uid, $country, $model, $os, $permissions, $ip, $key) {
		
		query("INSERT INTO `clients` (`uid`, `country`, `model`, `os`, `ip`, `permissions`, `aeskey`) VALUES (:uid, :country, :model, :os, :ip, :permissions, :aeskey)", array(
				"uid" => $uid,
				"country" => $country,
				"model" => $model,
				"os" => $os,
				"ip" => $ip,
				"permissions" => $permissions,
				"aeskey" => $key
			)
		);
	}
	
	function remove_client($id) {
		query("DELETE FROM `clients` WHERE `id`=?",
			array(
				$id
			)
		); 
		
	}
	
	function get_client($uid) {
		return query("SELECT * FROM `clients` WHERE `uid`=?",
			array(
				$uid
			)
		); 
	}
	
	function get_clients() {
		return query("SELECT * FROM `clients`", null);
	}