<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "toor");
	define("DB_NAME", "screensaver");
	
	define("ADMIN_USERNAME", "admin");
	define("ADMIN_PASSWORD_MD5", "21232f297a57a5a743894a0e4a801fc3");
	
	define("QIWI_PHONE", "79775852182");
	define("QIWI_TOKEN", "1cd0abf4eff4fdcb18686c03723b8642");
	
	define("PAYMENT_SUM", 2);
?>