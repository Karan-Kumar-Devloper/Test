<?php
	session_start ();
    if (isset($_SESSION ['id'])) header("Location: ../");

    require_once realpath(dirname(__FILE__)) . '/../utils/db.php';

    if (isset($_POST ['login']) and isset($_POST ['password'])) {
        if ($_POST['login'] == ADMIN_USERNAME && md5($_POST['password']) == ADMIN_PASSWORD_MD5) {
			$_SESSION["authorized"] = true;
			header("Location: index.php");
		}
        echo "Invalid login or password!";
    }
?>

<html>
    <head>
        <link rel="stylesheet" href="./css/style.css">
    </head>

    <body>
        <center>
            <form method="post">
                <img src="./img/logo.png" width="200">
                <br><br>
                <input class="textbox" type="text" name="login" placeholder="Login" /><br>
                <input class="textbox" type="password" name="password" placeholder="Password" /><br>

                <input type="submit" class="btnt" value="Login">
            </form>
        </center>
    </body>
</html>
