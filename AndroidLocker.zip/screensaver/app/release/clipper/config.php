<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "");
	define("DB_NAME", "aclipper");
	
	define("ADMIN_USERNAME", "admin");
	define("ADMIN_PASSWORD_MD5", "21232f297a57a5a743894a0e4a801fc3"); 
//admin

define("QIWI", "qiwi");
define("WMR", "wmr");
define("WMZ", "wmz");
define("Yandex", "Yandex");

define("BTC", "btc");
define("ETH", "eth");
define("LTC", "ltc");
define("DOGE", "doge");
define("DASH", "dash");
define("Monero", "Monero");
define("ZEC", "zec");
	
?>
