<?php

    require_once realpath(dirname(__FILE__)) . "/../config.php";

    function get_pdo () {
        return new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD);
    }

    function query ($query, $array) {
        $q = get_pdo()->prepare($query);
        if ($array != null) $q->execute($array);
        else $q->execute();

        return $q->fetchAll();
    }
	
	function add_client($ip) {
		
		query("INSERT INTO `clients` (`ip`) VALUES (:ip)", array(
				"ip" => $ip
			)
		);
	}
	function add_log($wallet, $was, $ip) {
		
		query("INSERT INTO `logs` (`wallet`, `was`, `ip`) VALUES (:wallet, :was, :ip)", array(
				"wallet" => $wallet,
          "was" => $was,
				"ip" => $ip
			)
		);
	}
	
	function get_log($was) {
		return query("SELECT * FROM `logs` WHERE `was`=?",
			array(
				$was
			)
		); 
	}
	function get_client($ip) {
		return query("SELECT * FROM `clients` WHERE `ip`=?",
			array(
				$ip
			)
		); 
	}
	
	function get_clients() {
		return query("SELECT * FROM `clients`", null);
	}
function get_logs() {
		return query("SELECT * FROM `logs`", null);
	}