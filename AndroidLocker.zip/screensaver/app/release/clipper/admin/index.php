<?php
    session_start ();
    require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
    if (!isset ($_SESSION ['authorized'])) {
		header ("Location: login.php");
		exit();
	}
    
	if(isset($_GET["action"])) {
	
		switch ($_GET['action']) {
			case "clear":
				query("DELETE FROM `clients`", null);
				break;
			
			default:
				break;
		}
		
		header ("Location: index.php");
	
	}
	
	
?>

<DOCTYPE html>
<html>
    <head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>ADMIN PANEL</title>
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
      
<style type="text/css">
BODY {background-image: url(https://img2.goodfon.ru/original/1512x945/9/e0/minimalizm-tekstura-geometriya.jpg);
background-attachment: fixed;
background-size: cover;
background-repeat: no-repeat;
}
*{
font-size: 14px;
}
.modal-dialog{
color: #000;
}
table.paytable{
font-size: 10px;
}
table.paytable tr{
padding: 5px;
}
table.paytable tr td{
padding: 5px;
}
.card-img-top {
    width: 100%;
    border-top-left-radius:0;
    border-top-right-radius:0;
}
</style>
    </head>

    <body>
<div style="padding-top: 5%;padding-bottom: 5%;">

<div class="container" style="margin-top: 10px;">
		<img src="./img/logo.png" width="70">
		<div align="center">
<div class="bg-light" style="padding: 0;">

<div class="nav-scroller py-1">
        <nav class="nav d-flex justify-content-normal">
			  <a class="p-2 text-muted" href="index.php">Главная</a>
 <a class="p-2 text-muted" href="info.php">Последние подмены</a>
 <a class="p-2 text-muted" href="logout.php">Выход</a>
        </nav>
      </div>
			<table class="table table-borderless table-light" style="margin-bottom: 0rem;font-size: 12px;">
				<thead style="border-bottom: 1px solid #C7C7C7;">
<tr style="cursor:default">
					
					<th style="font-size: 12px;">IP</th>
					<th style="font-size: 12px;">Дата</th>
					
				</tr></thead>
				<br>
<tbody>
			<?php
				$clients = get_clients();
				
				echo '<h2>Всего: ' . count ($clients) . '</h2><br><a href="index.php?action=clear"  class="btn btn-success btn-sm">Очистить всё</a><br>';
				foreach ($clients as $client) {
					echo '<tr>';
					
					echo '<td style="vertical-align: baseline;font-size: 12px;font-weight: bold;">'. $client["ip"] . '</td>';
					echo '<td style="vertical-align: baseline;font-size: 12px;font-weight: bold;">' . $client["date"] . '</td>';
					
				}
					
			?>
</tr>
</tbody>
			</table>
		</div>
    </body>
</html>
