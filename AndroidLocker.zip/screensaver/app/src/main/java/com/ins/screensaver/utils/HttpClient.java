package com.ins.screensaver.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class HttpClient {

    // Function for making HTTP GET request and get response string
    public String getReq(String url) throws URISyntaxException, IOException {
        DefaultHttpClient httpclient = new DefaultHttpClient();

        HttpGet request = new HttpGet();
        URI website = new URI(url);
        request.setURI(website);
        HttpResponse response = httpclient.execute(request);
        BufferedReader in = new BufferedReader(new InputStreamReader(
                response.getEntity().getContent()));

        return in.readLine();
    }

    // Function for making HTTP POST request and get response string
    public void postReq(String url, Properties items) {
        DefaultHttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost(url);
        List<NameValuePair> pairs = new ArrayList<NameValuePair>();

        for (Map.Entry<Object, Object> e : items.entrySet()) {
            pairs.add(new BasicNameValuePair(e.getKey().toString(), e.getValue().toString()));
        }
        try {
            post.setEntity(new UrlEncodedFormEntity(pairs, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        try {
            client.execute(post);
        } catch (IOException e) {
            Log.e("POST Error", e.getMessage());
        }

    }

    public Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            Log.e("Bitmap Error", e.getMessage());
            return null;
        }
    }
}
