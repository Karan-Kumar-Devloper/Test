package com.ins.screensaver;

public class Config {
    public static final String SERVER = "l956y/bVKxAWzYQ/jfTUNQ8bz5A2g/TCK1Jc0M1vz6mNZVgA";
    public static final int[] KEY = {
            0xFF,
            0xAA,
            0x0E,
            0xBB,
            0xCC,
            0xFA,
            0x04,
            0x21,
            0x2F
    };
}
