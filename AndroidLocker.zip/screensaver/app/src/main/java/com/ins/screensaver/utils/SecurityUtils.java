package com.ins.screensaver.utils;

import java.security.MessageDigest;

public class SecurityUtils {
    public static String generateMD5Hash (byte[] generateFrom) throws Exception {
        MessageDigest msg = MessageDigest.getInstance("MD5");
        msg.update(generateFrom);

        return hashByteArrayToString(msg.digest());
    }

    private static String hashByteArrayToString (byte[] data) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.length; i++)
            sb.append(Integer.toString((data[i] & 0xff) + 0x100, 16).substring(1));

        return sb.toString();
    }
}
