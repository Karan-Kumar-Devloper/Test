package com.ins.screensaver.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.ins.screensaver.MainActivity;
import com.ins.screensaver.services.CheckerService;
import com.ins.screensaver.utils.Memory;

public class OnBoot extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        String a = "";

        try {
           Memory _mem = new Memory(context);
           a = _mem.readMemoryKey("finished");
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.d("Data", a);

        if(a.equalsIgnoreCase("1")) {
            return;
        }

        context.startActivity(new Intent(context, MainActivity.class));
    }
}
