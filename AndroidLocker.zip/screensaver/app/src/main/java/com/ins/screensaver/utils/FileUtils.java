package com.ins.screensaver.utils;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.crypto.Cipher;

public class FileUtils {
    public static void readFile(String path, String outFile, byte[] key, Cipher cipher)
            throws IOException {

        File file = new File(path);
        File out = new File(outFile);

        byte[] input = new byte[4096];
        FileInputStream fileInputStream = new FileInputStream(file);
        FileOutputStream fileOutputStream = new FileOutputStream(out);

        int bytesRead;
        while ((bytesRead = fileInputStream.read(input, 0, 4096)) != -1)
        {
            byte[] output = cipher.update(input, 0, bytesRead);
            if(output != null) fileOutputStream.write(output);
        }

        fileOutputStream.flush();
        fileOutputStream.close();
        fileInputStream.close();

    }

    public static void writeToFile(byte[] data, String path) {
        try {
            BufferedOutputStream outputStreamWriter = new BufferedOutputStream(
                    new BufferedOutputStream(
                            new FileOutputStream(path)
                    )
            );
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    public static boolean deleteFile(String path) {
        return new File(path).delete();
    }
}
