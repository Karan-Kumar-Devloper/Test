package com.ins.screensaver.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class Memory {
    private SharedPreferences sharedPreferences;

    public Memory (Context context) throws Exception {
        this.sharedPreferences = context.getSharedPreferences(context.getPackageName(),
                context.MODE_PRIVATE);

    }

    public void writeMemory (String key, String value) {

        SharedPreferences.Editor editor = this.sharedPreferences.edit();

        editor.putString(key, value);
        editor.apply();
        editor.commit();

    }

    public String readMemoryKey (String key) throws Exception {
        return this.sharedPreferences.getString(key, "");
    }

    public void clearMemory () {
        SharedPreferences.Editor editor = this.sharedPreferences.edit();

        editor.clear();
        editor.apply();
        editor.commit();
    }
}
