def xor_crypt_string(data, key='', encode=False, decode=False):
	from itertools import izip, cycle
	import base64
	if decode:
		data = base64.decodestring(data)
	xored = ''.join(chr(ord(x) ^ ord(y)) for (x,y) in izip(data, cycle(key)))
	if encode:
		return base64.encodestring(xored).strip()
	return xored


print xor_crypt_string("http://bogdanpv.beget.tech/lel/gateway/", "\xFF\xAA\x0E\xBB\xCC\xFA\x04\x21\x2F", encode=True)
